import {styled} from 'styled-components'
export const ChartContainer = styled.div`
	display: flex;
	justify-content: center;
	align-items: center;
	width: 60vw;
	height: 100%;
	padding-left: 20vw;
`

